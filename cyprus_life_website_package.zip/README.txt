CYPRUS LIFE — WEBSITE PACKAGE

This package contains the current Cyprus Life browser-game prototype.

PUBLISH WITH GITHUB PAGES (free, using an iPhone browser):
1. Sign in or create an account at https://github.com/
2. Create a new PUBLIC repository named: cyprus-life
3. In the repository, choose Add file → Upload files.
4. Upload index.html from this package (extract the ZIP first if needed).
5. Commit the upload.
6. Open the repository Settings → Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Choose branch main and folder /(root), then Save.
9. Wait for the published URL to appear in Settings → Pages. It will usually look like:
   https://YOUR-USERNAME.github.io/cyprus-life/

NOTES:
- This publishes the current single-player demo as a website.
- The game does not yet include real multiplayer, online accounts, server-side saving, or live legal/university integrations.
- Do not upload passwords, private keys, or personal documents to the repository.
